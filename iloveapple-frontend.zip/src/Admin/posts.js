import React from 'react';
import { Grid, Header } from 'semantic-ui-react'

const Posts = () => (
  <Grid.Row className="wrapper">
	  
	  <Grid.Column computer={12} mobile={16}>
	  	
	  	<p>This is an example of a WordPress page, you could edit this to put information about yourself or your site so readers know where you are coming from. You can create as many pages like this one or sub-pages as you like and manage all of your content inside of WordPress.</p>
	  </Grid.Column>	
  </Grid.Row>
);




export default Posts;